<div>
<div>
    <label for="">Pretendes parcelar de quantas Vezes</label>
    <select name="" id="" wire:model="parcelas">
        <option value="1">à vista</option>
        <option value="4">4x</option>
        <option value="10">10x</option>
        <option value="15">15</option>
        <option value="20">20</option>
        <option value="24">24</option>
    </select>
</div>
<?php echo json_encode($parcelas, 15, 512) ?> <br><br>
<?php echo json_encode($preco, 15, 512) ?> <br><br>
<?php echo json_encode($total, 15, 512) ?><br><br>
<div>
    <div>
        <button wire:click="calc">Calcular</button>
        <?php echo json_encode($total, 15, 512) ?>
        <h1><?php echo e($total); ?></h1>
    </div>
</div>
</div>
<?php /**PATH C:\projetos php\arma-legal\resources\views/livewire/calcular.blade.php ENDPATH**/ ?>