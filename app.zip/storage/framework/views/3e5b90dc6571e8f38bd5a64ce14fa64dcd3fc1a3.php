<?php $__env->startSection('content'); ?>
    <main class="flex lg:flex-row flex-col h-[100vh] ">
        <div class="lg:w-[20%] lg:overflow-hidden lg:h-[100vh]">
            <img src="/Imgs/soldado.jpg" class="h-[100vh]" alt="">
        </div>

        <div class="lg:w-[80%] lg:h-[100vh] justify-start lg:overflow-auto bg-zinc-950">

            <div id="alert-border-4"
                class="flex p-4 mb-4 mt-4 w-[90%] m-auto text-yellow-800 border-t-4 border-yellow-300 bg-yellow-50 dark:text-yellow-300 dark:bg-gray-800 dark:border-yellow-800"
                role="alert">
                <svg class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                        clip-rule="evenodd"></path>
                </svg>
                <div class="ml-3 text-sm font-medium uppercase">
                    Antes de tudo, veja alguns requisitos para obter o Financiamento <a href="<?php echo e(route('infor')); ?>">
                        <button type="button" class="font-semibold underline hover:no-underline uppercase">
                            clicando aqui </button>
                    </a>
                </div>
                <button type="button"
                    class="ml-auto -mx-1.5 -my-1.5 bg-yellow-50 text-yellow-500 rounded-lg focus:ring-2 focus:ring-yellow-400 p-1.5 hover:bg-yellow-200 inline-flex h-8 w-8 dark:bg-gray-800 dark:text-yellow-300 dark:hover:bg-gray-700"
                    data-dismiss-target="#alert-border-4" aria-label="Close">
                    <span class="sr-only">Dismiss</span>
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                            clip-rule="evenodd"></path>
                    </svg>
                </button>
            </div>

            <h1 class="text-white text-center text-4xl m-8">Nossos Modelos</h1>

            <!-- TAURUS------------------- -->
            <div id="accordion-collapse" data-accordion="collapse" class="w-[90%] m-auto mb-8">
                <h2 id="accordion-collapse-heading-1" class="border-b-2">
                    <button type="button"
                        class="flex items-center justify-between w-full p-5 font-medium text-left text-gray-500 border border-b-0  border-gray-900  focus:ring-4 bg-gray-900 focus:ring-gray-200 hover:bg-gray-600"
                        data-accordion-target="#accordion-collapse-body-1" aria-expanded="true"
                        aria-controls="accordion-collapse-body-1">
                        <span class="text-white">TAURUS
                            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0 text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                    clip-rule="evenodd"> </path>
                            </svg>
                    </button>
                </h2>
                <div id="accordion-collapse-body-1" class="hidden bg-zinc-900"
                    aria-labelledby="accordion-collapse-heading-1" class="">

                    <!-- Pistolas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col flex-wrap mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Pistolas</h2>

                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $pistolaTaurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pistolaT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($pistolaT->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($pistolaT->nome); ?></p>
                                        <span>Calibre: <?php echo e($pistolaT->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($pistolaT->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaT->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaT->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaT->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->qtd_raias); ?> /
                                                                            <?php echo e($pistolaT->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->qtd_cano); ?> /
                                                                            <?php echo e($pistolaT->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaT->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($pistolaT->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $pistolaT->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                    <!-- Revólveres ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Revólveres</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $revolverTaurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revolverT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($revolverT->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($revolverT->nome); ?></p>
                                        <span>Calibre: <?php echo e($revolverT->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($revolverT->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverT->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverT->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverT->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->qtd_raias); ?> /
                                                                            <?php echo e($revolverT->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->qtd_cano); ?> /
                                                                            <?php echo e($revolverT->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverT->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($revolverT->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $revolverT->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Armas Longas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Armas Longas</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $longasTaurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $longasT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($longasT->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($longasT->nome); ?></p>
                                        <span>Calibre: <?php echo e($longasT->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($longasT->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasT->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasT->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasT->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->qtd_raias); ?> /
                                                                            <?php echo e($longasT->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->qtd_cano); ?> /
                                                                            <?php echo e($longasT->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasT->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($longasT->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $longasT->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CBC------------------- -->
            <div id="accordion-collapse" data-accordion="collapse" class="w-[90%] m-auto mb-8">
                <h2 id="accordion-collapse-heading-2" class="border-b-2">
                    <button type="button"
                        class="flex items-center justify-between w-full p-5 font-medium text-left text-gray-500 border border-b-0  border-gray-900  focus:ring-4 bg-gray-900 focus:ring-gray-200 hover:bg-gray-600"
                        data-accordion-target="#accordion-collapse-body-2" aria-expanded="true"
                        aria-controls="accordion-collapse-body-2">
                        <span class="text-white">CBC
                            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0 text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                    clip-rule="evenodd"> </path>
                            </svg>
                    </button>
                </h2>
                <div id="accordion-collapse-body-2" class="hidden bg-zinc-900"
                    aria-labelledby="accordion-collapse-heading-2" class="">

                    <!-- Pistolas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Pistolas</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $pistolaCBC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pistolaC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($pistolaC->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($pistolaC->nome); ?></p>
                                        <span>Calibre: <?php echo e($pistolaC->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($pistolaC->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaC->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaC->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaC->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->qtd_raias); ?> /
                                                                            <?php echo e($pistolaC->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->qtd_cano); ?> /
                                                                            <?php echo e($pistolaC->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaC->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($pistolaC->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $pistolaC->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Revólveres ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Revólveres</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $revolverCBC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revolverC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($revolverC->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($revolverC->nome); ?></p>
                                        <span>Calibre: <?php echo e($revolverC->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($revolverC->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverC->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverC->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverC->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->qtd_raias); ?> /
                                                                            <?php echo e($revolverC->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->qtd_cano); ?> /
                                                                            <?php echo e($revolverC->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverC->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($revolverC->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $revolverC->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Armas Longas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Armas Longas</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $longasCBC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $longasC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($longasC->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($longasC->nome); ?></p>
                                        <span>Calibre: <?php echo e($longasC->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($longasC->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel" class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasC->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasC->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasC->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->qtd_raias); ?> /
                                                                            <?php echo e($longasC->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->qtd_cano); ?> /
                                                                            <?php echo e($longasC->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasC->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($longasC->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $longasC->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GLOCK------------------- -->
            <div id="accordion-collapse" data-accordion="collapse" class="w-[90%] m-auto mb-8">
                <h2 id="accordion-collapse-heading-3" class="border-b-2">
                    <button type="button"
                        class="flex items-center justify-between w-full p-5 font-medium text-left text-gray-500 border border-b-0  border-gray-900  focus:ring-4 bg-gray-900 focus:ring-gray-200 hover:bg-gray-600"
                        data-accordion-target="#accordion-collapse-body-3" aria-expanded="true"
                        aria-controls="accordion-collapse-body-3">
                        <span class="text-white">GLOCK
                            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0 text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                    clip-rule="evenodd"> </path>
                            </svg>
                    </button>
                </h2>
                <div id="accordion-collapse-body-3" class="hidden bg-zinc-900"
                    aria-labelledby="accordion-collapse-heading-3" class="">

                    <!-- Pistolas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Pistolas</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $pistolaGlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pistolaG): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($pistolaG->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($pistolaG->nome); ?></p>
                                        <span>Calibre: <?php echo e($pistolaG->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($pistolaG->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel"
                                                            class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaG->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaG->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($pistolaG->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->qtd_raias); ?> /
                                                                            <?php echo e($pistolaG->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->qtd_cano); ?> /
                                                                            <?php echo e($pistolaG->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($pistolaG->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($pistolaG->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $pistolaG->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Revólveres ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Revólveres</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $revolverGlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revolverG): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($revolverG->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($revolverG->nome); ?></p>
                                        <span>Calibre: <?php echo e($revolverG->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($revolverG->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel"
                                                            class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverG->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverG->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($revolverG->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->qtd_raias); ?> /
                                                                            <?php echo e($revolverG->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->qtd_cano); ?> /
                                                                            <?php echo e($revolverG->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($revolverG->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($revolverG->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $revolverG->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Armas Longas ---->
                    <div class=" border-gray-800 w-[90%] m-auto pb-8 rounded-xl flex flex-col mb-8">
                        <h2 class="text-center m-4 text-2xl text-white">Armas Longas</h2>
                        <div class="grid xl:grid-cols-3 lg:grid-cols-2 gap-8 m-auto">
                            <?php $__currentLoopData = $longasGlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $longasG): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Card da arma -->
                                <div
                                    class="border w-[17em] row-span-1 h-[28em] flex flex-nowrap flex-col justify-center items-center border-gray-300  bg-gray-700 p-4 rounded-md ">
                                    <!-- Img da arma -->
                                    <div class="mb-4 w-[15em]">
                                        <img class="rounded-md" src="<?php echo e($longasG->img1); ?>" alt="pistola taurus">
                                    </div>
                                    <!-- Corpo do card -->
                                    <div class="text-center flex flex-col text-white gap-2">
                                        <p>PT <?php echo e($longasG->nome); ?></p>
                                        <span>Calibre: <?php echo e($longasG->calibre); ?></span>
                                        <span>Capacidade de tiro <?php echo e($longasG->capacidade_tiro); ?></span>

                                        <!-- Modal toggle -->
                                        <button data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                            class="block text-white bg-gray-900  hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            type="button">
                                            Mais detalhes
                                        </button>

                                        <!-- Main modal -->
                                        <div id="defaultModal" tabindex="-1" aria-hidden="true"
                                            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-2rem)] lg:max-h-full">
                                            <div class="relative m-auto  p-4">
                                                <!-- Modal content -->
                                                <div class="relative  bg-white rounded-lg shadow dark:bg-gray-700">
                                                    <!-- Modal body -->
                                                    <div class="p-6 rounded-t space-y-6">

                                                        <div id="default-carousel"
                                                            class="lg:block hidden relative w-full"
                                                            data-carousel="slide">
                                                            <!-- Carousel wrapper -->
                                                            <div
                                                                class="relative  w-full overflow-hidden rounded-lg lg:h-96">
                                                                <!-- Item 1 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasG->img1); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>

                                                                <!-- Item 2 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasG->img2); ?>"
                                                                        class="absolute w-[20em] block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                                <!-- Item 3 -->
                                                                <div class="hidden duration-700 ease-in-out"
                                                                    data-carousel-item>
                                                                    <img src="<?php echo e($longasG->img3); ?>"
                                                                        class="absolute w-[20em] block  -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                                                        alt="...">
                                                                </div>
                                                            </div>
                                                            <!-- Slider indicators -->
                                                            <div
                                                                class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2 bg-black p-4 rounded-lg">
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="true" aria-label="Slide 1"
                                                                    data-carousel-slide-to="0"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 2"
                                                                    data-carousel-slide-to="1"></button>
                                                                <button type="button" class="w-3 h-3 rounded-full"
                                                                    aria-current="false" aria-label="Slide 3"
                                                                    data-carousel-slide-to="2"></button>
                                                            </div>
                                                            <!-- Slider controls -->
                                                            <button type="button"
                                                                class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-prev>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M15 19l-7-7 7-7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Previous</span>
                                                                </span>
                                                            </button>
                                                            <button type="button"
                                                                class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                                                                data-carousel-next>
                                                                <span
                                                                    class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-black group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                                                                    <svg aria-hidden="true"
                                                                        class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800"
                                                                        fill="none" stroke="currentColor"
                                                                        viewBox="0 0 24 24"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M9 5l7 7-7 7"></path>
                                                                    </svg>
                                                                    <span class="sr-only">Next</span>
                                                                </span>
                                                            </button>
                                                        </div>

                                                        <div class="flex lg:flex-row flex-col gap-4 justify-center">
                                                            <div>
                                                                <H3 class="text-black font-bold">DADOS TÉCNICOS</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CALIBRE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->calibre); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ACABAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->acabamento); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            CAPACIDADE DE TIRO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->capacidade_tiro); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            SIST.
                                                                            DE FUNCIONAMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->sistema_funcionamento); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            RAIAS/SENTIDO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->qtd_raias); ?> /
                                                                            <?php echo e($longasG->sentido_raias); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">QTD
                                                                            CANO / COMPRIMENTO</th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->qtd_cano); ?> /
                                                                            <?php echo e($longasG->comprimento_cano); ?>

                                                                        </td>
                                                                    </tr>

                                                                </table>
                                                            </div>

                                                            <div>
                                                                <H3 class="text-black font-bold">INFORMAÇÕES</H3>
                                                                <table
                                                                    class=" m-auto text-sm text-white bg-gray-800 text-left">


                                                                    <tr class=" text-center">
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DESCRIÇÃO
                                                                        </th>
                                                                        <th scope="row" class="px-6 py-3 border">
                                                                            DETALHE
                                                                        </th>

                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">PAÍS
                                                                            DE FABRICAÇÃO
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->pais_fabricacao); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            ESPÉCIE
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->tipo); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            MARCA
                                                                            </th>
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            <?php echo e($longasG->fabricante); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr class="text-center">
                                                                        <td scope="row" class="px-6 py-4 border">
                                                                            PREÇO
                                                                            À VISTA</th>
                                                                        <td scope="row" class="px-6 py-4 border"> R$
                                                                            <?php echo e($longasG->preco); ?>,00
                                                                        </td>
                                                                    </tr>


                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Modal footer -->
                                                    <div
                                                        class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600 w-full">
                                                        <button data-modal-hide="defaultModal" type="button"
                                                            class="text-white w-[30%] bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                            Fechar
                                                        </button>

                                                        <a class="text-white w-[100%] bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5"
                                                            href="<?php echo e(route('simulador', ['id' => $longasG->id])); ?>"
                                                            target="_blank"><button type="button">Simular Financiamento
                                                            </button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos php\arma-legal\resources\views/catalogo.blade.php ENDPATH**/ ?>