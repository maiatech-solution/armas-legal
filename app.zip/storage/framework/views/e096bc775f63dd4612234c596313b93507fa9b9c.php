<?php $__env->startSection('content'); ?>
   <div><?php echo json_encode(session()->get('associado'), 15, 512) ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos php\arma-legal\resources\views/teste.blade.php ENDPATH**/ ?>